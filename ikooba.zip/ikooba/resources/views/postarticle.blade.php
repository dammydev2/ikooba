@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-10">
    		<div class="panel-heading">Article</div>
    		<div class="panel-body">
    			
                @foreach($data as $row)

                <p>
                    <h3>Title</h3>
                    <i>{{ $row->title }}</i>
                </p>

                <p>
                    <h3>Article</h3>
                    {{ $row->article }}
                </p>

                @endforeach

    		</div>
    	</div>


    </div>
</div>
@endsection
