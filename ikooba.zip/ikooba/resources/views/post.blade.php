@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-10">
    		<div class="panel-heading">My Post</div>
    		<div class="panel-body">
    			
    			@if(Session::has('success'))
                <div class="alert alert-success">{{ Session::get('success') }}</div>
                @endif

                @if(Session::has('error'))
                <div class="alert alert-danger">{{ Session::get('error') }}</div>
                @endif

                <table class="table table-bordered">
                    <tr>
                        <th>Title</th>
                        <th>edit</th>
                        <th>delete</th>
                    </tr>

                    @foreach($data as $row)
                    <tr>
                        <td>{{ $row->title }} <a href="{{url('/postarticle/'.$row->id)}}">View article</a></td>
                        <td><a href="{{ url('/postedit/'.$row->id) }}"><i class="fa fa-edit"></i></a></td>
                        <td><a href="{{ url('/postdelete/'.$row->id) }}"><i class="fa fa-trash btn btn-danger"></i></a></td>
                    </tr>
                    @endforeach

                </table>

                {{ $data->links() }}

    		</div>
    	</div>


    </div>
</div>
@endsection
