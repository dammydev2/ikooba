<li><a href="{{ url('/home') }}">Add Post</a></li>
<li><a href="{{ url('/post') }}">show my Post</a></li>