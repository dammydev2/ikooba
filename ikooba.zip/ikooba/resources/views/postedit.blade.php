@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-5">
    		<div class="panel-heading">Add Post</div>
    		<div class="panel-body">
    			
    			<form method="post" action="{{ url('/updatepost') }}">
    				{{ csrf_field() }}

    				@if ($errors->any())
					<div class="alert alert-danger">
						@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
						@endforeach
					</div>
					@endif

                    @foreach($data as $row)
    				<div class="form-group">
    					<label>Title</label>
    					<input type="text" name="title" value="{{ $row->title }}" class="form-control">
    				</div>

    				<div class="form-group">
    					<label>Article</label>
    					<textarea class="form-control" name="article"> {{ $row->article }} </textarea>
    				</div>

                    <input type="hidden" name="id" value="{{ $row->id }}">

                    @endforeach

    				<input type="submit" class="btn btn-primary" value="update post" name="">

    			</form>

    		</div>
    	</div>


    </div>
</div>
@endsection
