@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-5">
    		<div class="panel-heading">Add Post</div>
    		<div class="panel-body">
    			
    			<form method="post" action="{{ url('/enterpost') }}">
    				{{ csrf_field() }}

    				@if ($errors->any())
					<div class="alert alert-danger">
						@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
						@endforeach
					</div>
					@endif

    				<div class="form-group">
    					<label>Title</label>
    					<input type="text" name="title" class="form-control">
    				</div>

    				<div class="form-group">
    					<label>Article</label>
    					<textarea class="form-control" name="article"></textarea>
    				</div>

    				<input type="submit" class="btn btn-primary" value="Add post" name="">

    			</form>

    		</div>
    	</div>


    </div>
</div>
@endsection
