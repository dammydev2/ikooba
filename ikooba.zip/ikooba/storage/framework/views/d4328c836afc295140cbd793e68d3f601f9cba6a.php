<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-5">
    		<div class="panel-heading">Add Post</div>
    		<div class="panel-body">
    			
    			<form method="post" action="<?php echo e(url('/updatepost')); ?>">
    				<?php echo e(csrf_field()); ?>


    				<?php if($errors->any()): ?>
					<div class="alert alert-danger">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php endif; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<div class="form-group">
    					<label>Title</label>
    					<input type="text" name="title" value="<?php echo e($row->title); ?>" class="form-control">
    				</div>

    				<div class="form-group">
    					<label>Article</label>
    					<textarea class="form-control" name="article"> <?php echo e($row->article); ?> </textarea>
    				</div>

                    <input type="hidden" name="id" value="<?php echo e($row->id); ?>">

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    				<input type="submit" class="btn btn-primary" value="update post" name="">

    			</form>

    		</div>
    	</div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ikooba\resources\views/postedit.blade.php ENDPATH**/ ?>