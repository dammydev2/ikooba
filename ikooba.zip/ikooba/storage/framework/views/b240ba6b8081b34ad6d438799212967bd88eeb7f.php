<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-10">
    		<div class="panel-heading">Add Post</div>
    		<div class="panel-body">
    			
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <p>
                    <h3>Title</h3>
                    <i><?php echo e($row->title); ?></i>
                </p>

                <p>
                    <h3>Article</h3>
                    <?php echo e($row->article); ?>

                </p>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    		</div>
    	</div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ikooba\resources\views/postarticle.blade.php ENDPATH**/ ?>