<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<div class="panel panel-primary col-sm-10">
    		<div class="panel-heading">My Post</div>
    		<div class="panel-body">
    			
    			<?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>

                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>

                <table class="table table-bordered">
                    <tr>
                        <th>Title</th>
                        <th>edit</th>
                        <th>delete</th>
                    </tr>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->title); ?> <a href="<?php echo e(url('/postarticle/'.$row->id)); ?>">View article</a></td>
                        <td><a href="<?php echo e(url('/postedit/'.$row->id)); ?>"><i class="fa fa-edit"></i></a></td>
                        <td><a href="<?php echo e(url('/postdelete/'.$row->id)); ?>"><i class="fa fa-trash btn btn-danger"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

                <?php echo e($data->links()); ?>


    		</div>
    	</div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ikooba\resources\views/post.blade.php ENDPATH**/ ?>