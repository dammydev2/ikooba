<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mypost extends Model
{
    protected $fillable = ['title', 'article', 'name', 'user_id'];
}
