<?php

namespace App\Http\Controllers;
use App\Mypost;

use Illuminate\Http\Request;

class FrontController extends Controller
{
   
   public function front()
    {
        $data = Mypost::orderBy('id', 'desc')->get();
        return view('front', compact('data'));
    }
}
