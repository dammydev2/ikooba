<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\Mypost;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        return view('home');
    }

    public function enterpost(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'article' => 'required',
        ]);
        Mypost::create([
            'title' => $request['title'],
            'article' => $request['article'],
            'name' => \Auth::User()->name,
            'user_id' => \Auth::User()->id
        ]);
        Session::flash('success', 'post created successfully');
        return redirect('post');
    }

    public function post()
    {
        $id = \Auth::User()->id;
        $data = Mypost::where('user_id', $id)
        ->orderBy('id', 'desc')
        ->paginate(10);
        return view('post', compact('data'));
    }

    public function postarticle($id)
    {
         $data = Mypost::where('id', $id)->get();
         return view('postarticle', compact('data'));
    }

    public function postedit($id)
    {
         $data = Mypost::where('id', $id)->get();
         return view('postedit', compact('data'));
    }

    public function updatepost(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'article' => 'required',
        ]);
        Mypost::where('id', $request['id'])
        ->update([
            'title' => $request['title'],
            'article' => $request['article'],
        ]);
        Session::flash('success', 'post updated successfully');
        return redirect('post');
    }

    public function postdelete($id)
    {
        Mypost::where('id', $id)->delete();
        Session::flash('error', 'Post deleted successfully');
        return redirect('post');
    }

}
